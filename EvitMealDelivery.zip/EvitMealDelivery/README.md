# Sidescroller-Quickstart-Godot-4
Tutorial project to demo how to setup a sidescrolling character with animations, smooth camera, and simple tilemap collisions

== Controls ==

A - Move Left

D - Move Right

Space - Jump

